import React, { useState } from 'react';
import { format, subDays } from 'date-fns';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { ForecastData, ForecastMetrics, FeatureContribution } from '../types';

interface Props {
  forecastData: ForecastData[];
  metrics: ForecastMetrics;
  featureContributions: FeatureContribution[];
}

const Forecasting: React.FC<Props> = ({ forecastData, metrics, featureContributions }) => {
  const [timeframe, setTimeframe] = useState('30');
  const [interval, setInterval] = useState('day');

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">AI Forecast Analysis</h2>
          
          <div className="flex space-x-4">
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              className="rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
            >
              <option value="7">Last 7 days</option>
              <option value="30">Last 30 days</option>
              <option value="90">Last 90 days</option>
            </select>
            
            <select
              value={interval}
              onChange={(e) => setInterval(e.target.value)}
              className="rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
            >
              <option value="day">Daily</option>
              <option value="week">Weekly</option>
              <option value="month">Monthly</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="text-sm text-blue-600 mb-1">Forecast Accuracy</div>
            <div className="text-2xl font-bold text-blue-700">{metrics.accuracy.toFixed(1)}%</div>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4">
            <div className="text-sm text-green-600 mb-1">Forecast Bias</div>
            <div className="text-2xl font-bold text-green-700">{metrics.bias > 0 ? '+' : ''}{metrics.bias.toFixed(1)}%</div>
          </div>
          
          <div className="bg-purple-50 rounded-lg p-4">
            <div className="text-sm text-purple-600 mb-1">Volume Change</div>
            <div className="text-2xl font-bold text-purple-700">{metrics.volumeChange > 0 ? '+' : ''}{metrics.volumeChange.toFixed(1)}%</div>
          </div>
          
          <div className="bg-orange-50 rounded-lg p-4">
            <div className="text-sm text-orange-600 mb-1">Next Forecast</div>
            <div className="text-2xl font-bold text-orange-700">{format(metrics.nextRunDate, 'MMM d')}</div>
          </div>
        </div>

        <div className="h-96 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={forecastData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => format(new Date(date), 'MMM d')}
              />
              <YAxis />
              <Tooltip
                labelFormatter={(date) => format(new Date(date), 'PPP')}
                formatter={(value: number) => [value.toLocaleString(), '']}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="actualSales" 
                stroke="#2563eb" 
                name="Actual Sales"
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="aiForecast" 
                stroke="#16a34a" 
                name="AI Forecast"
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="consensusForecast" 
                stroke="#9333ea" 
                name="Consensus"
                strokeWidth={2}
                strokeDasharray="5 5"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium text-gray-800 mb-4">Feature Contributions</h3>
            <div className="space-y-3">
              {featureContributions.map((feature) => (
                <div key={feature.feature} className="bg-gray-50 rounded-lg p-3">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">{feature.feature}</span>
                    <span className="text-sm text-gray-500">{feature.importance.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${feature.importance}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-800 mb-4">Forecast Schedule</h3>
            <div className="bg-gray-50 rounded-lg p-4 space-y-4">
              <div>
                <div className="text-sm text-gray-500 mb-1">Last Run</div>
                <div className="font-medium">{format(metrics.lastRunDate, 'PPP')}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500 mb-1">Next Run</div>
                <div className="font-medium">{format(metrics.nextRunDate, 'PPP')}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500 mb-1">Forecast Horizon</div>
                <div className="font-medium">90 Days</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Forecasting;