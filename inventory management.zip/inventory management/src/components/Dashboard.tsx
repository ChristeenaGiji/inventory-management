import React, { useEffect, useState } from 'react';
import { 
  BarChart3, Package, TrendingUp, DollarSign, AlertTriangle, 
  Truck, Box, Factory, ShoppingCart, Clock, CheckCircle2
} from 'lucide-react';
import { 
  InventoryItem, OptimizationMetrics, UncertaintyMetrics,
  OrderData, MaterialData, FacilityData 
} from '../types';
import { aiAgents } from '../services/aiAgents';
import { 
  generateMockInventoryItems, 
  generateOrderData, 
  generateMaterialData, 
  generateFacilityData 
} from '../services/mockData';

const Dashboard: React.FC = () => {
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [metrics, setMetrics] = useState<OptimizationMetrics>({
    inventoryReduction: 0,
    serviceLevelImprovement: 0,
    costSavings: 0,
    otifImprovement: 0,
    holdingCostReduction: 0,
    shippingCostReduction: 0,
    customerSatisfaction: 0
  });
  const [uncertainties, setUncertainties] = useState<UncertaintyMetrics>({
    demandUncertainty: 0,
    supplierDelay: 0,
    blockedMovement: 0,
    supplierQuantity: 0,
    materialQuality: 0
  });
  const [orderData] = useState<OrderData>(generateOrderData());
  const [materialData] = useState<MaterialData>(generateMaterialData());
  const [facilities] = useState<FacilityData[]>(generateFacilityData());

  useEffect(() => {
    // Simulate real-time data updates
    const items = generateMockInventoryItems();
    setInventoryItems(items);

    // AI agents process the data
    const optimizationMetrics = aiAgents.optimization.calculateOptimizationMetrics(items);
    const uncertaintyMetrics = aiAgents.uncertainty.predictUncertainties(items);

    setMetrics(optimizationMetrics);
    setUncertainties(uncertaintyMetrics);

    // Simulate real-time updates
    const updateInterval = setInterval(() => {
      const updatedItems = items.map(item => ({
        ...item,
        currentStock: item.currentStock + Math.floor(Math.random() * 10) - 5,
        demandVariability: item.demandVariability + (Math.random() * 0.02 - 0.01)
      }));

      setInventoryItems(updatedItems);
      setMetrics(aiAgents.optimization.calculateOptimizationMetrics(updatedItems));
      setUncertainties(aiAgents.uncertainty.predictUncertainties(updatedItems));
    }, 5000);

    return () => clearInterval(updateInterval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Package className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-3xl font-bold text-gray-900">AI Inventory Optimization</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                <CheckCircle2 className="w-4 h-4 mr-1" />
                AI Active
              </span>
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                <Clock className="w-4 h-4 mr-1" />
                Real-time Updates
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {/* Primary Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <BarChart3 className="h-6 w-6 text-blue-600" />
              <h3 className="ml-2 text-lg font-semibold text-gray-700">Inventory Optimization</h3>
            </div>
            <p className="mt-2 text-3xl font-bold text-blue-600">{metrics.inventoryReduction}%</p>
            <p className="text-sm text-gray-500">Reduction in holding costs</p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <TrendingUp className="h-6 w-6 text-green-600" />
              <h3 className="ml-2 text-lg font-semibold text-gray-700">Service Level</h3>
            </div>
            <p className="mt-2 text-3xl font-bold text-green-600">{metrics.serviceLevelImprovement}%</p>
            <p className="text-sm text-gray-500">OTIF Performance Improvement</p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <DollarSign className="h-6 w-6 text-purple-600" />
              <h3 className="ml-2 text-lg font-semibold text-gray-700">Cost Impact</h3>
            </div>
            <p className="mt-2 text-3xl font-bold text-purple-600">${metrics.costSavings.toLocaleString()}</p>
            <p className="text-sm text-gray-500">Total cost savings</p>
          </div>
        </div>

        {/* Uncertainty Metrics */}
        <div className="bg-white shadow rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">AI Uncertainty Predictions</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {Object.entries(uncertainties).map(([key, value]) => (
              <div key={key} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center mb-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mr-2" />
                  <h3 className="text-sm font-medium text-gray-700">
                    {key.split(/(?=[A-Z])/).join(' ')}
                  </h3>
                </div>
                <p className="text-2xl font-bold text-amber-600">{(value * 100).toFixed(1)}%</p>
              </div>
            ))}
          </div>
        </div>

        {/* Order and Material Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Order Statistics</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <ShoppingCart className="h-5 w-5 text-blue-500 mr-2" />
                  <span className="text-gray-700">Sales Orders</span>
                </div>
                <span className="font-semibold">{orderData.salesOrders}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Factory className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700">Production Orders</span>
                </div>
                <span className="font-semibold">{orderData.productionOrders}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <CheckCircle2 className="h-5 w-5 text-purple-500 mr-2" />
                  <span className="text-gray-700">Fulfillment Rate</span>
                </div>
                <span className="font-semibold">{orderData.orderFulfillmentRate}%</span>
              </div>
            </div>
          </div>

          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Material Movement</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Box className="h-5 w-5 text-blue-500 mr-2" />
                  <span className="text-gray-700">Total Materials</span>
                </div>
                <span className="font-semibold">{materialData.totalMaterials}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Truck className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700">Material Movements</span>
                </div>
                <span className="font-semibold">{materialData.materialMovements}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
                  <span className="text-gray-700">Blocked Materials</span>
                </div>
                <span className="font-semibold">{materialData.blockedMaterials}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Inventory Table */}
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">AI-Optimized Inventory</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Optimal Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service Level</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">OTIF</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {inventoryItems.map((item) => (
                  <tr key={item.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{item.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.category}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.currentStock}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.optimalStock}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.serviceLevel}%</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.otifPerformance}%</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        item.currentStock > item.optimalStock 
                          ? 'bg-red-100 text-red-800' 
                          : item.currentStock < item.reorderPoint
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {item.currentStock > item.optimalStock 
                          ? 'Overstock' 
                          : item.currentStock < item.reorderPoint
                          ? 'Reorder'
                          : 'Optimal'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;