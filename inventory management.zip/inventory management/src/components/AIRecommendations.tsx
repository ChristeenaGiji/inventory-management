import React, { useState } from 'react';
import { format } from 'date-fns';
import { 
  CheckCircle2, AlertTriangle, TrendingUp, DollarSign, 
  ThumbsUp, ThumbsDown, BarChart4 
} from 'lucide-react';
import { AIRecommendation, InventoryItem } from '../types';

interface Props {
  recommendations: AIRecommendation[];
  items: InventoryItem[];
  onAccept: (rec: AIRecommendation) => void;
  onReject: (rec: AIRecommendation) => void;
}

const AIRecommendations: React.FC<Props> = ({ recommendations, items, onAccept, onReject }) => {
  const [selectedRec, setSelectedRec] = useState<AIRecommendation | null>(null);

  const getItem = (itemId: string) => items.find(item => item.id === itemId);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'bg-yellow-100 text-yellow-800';
      case 'APPROVED': return 'bg-green-100 text-green-800';
      case 'REJECTED': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">AI Recommendations</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <AlertTriangle className="h-5 w-5 text-blue-600 mr-2" />
              <span className="font-medium">Open Recommendations</span>
            </div>
            <p className="text-2xl font-bold text-blue-600">
              {recommendations.filter(r => r.status === 'PENDING').length}
            </p>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <TrendingUp className="h-5 w-5 text-green-600 mr-2" />
              <span className="font-medium">Potential Savings</span>
            </div>
            <p className="text-2xl font-bold text-green-600">
              ${recommendations.reduce((sum, r) => sum + r.potentialCostImpact, 0).toLocaleString()}
            </p>
          </div>
          
          <div className="bg-purple-50 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <BarChart4 className="h-5 w-5 text-purple-600 mr-2" />
              <span className="font-medium">Avg. Confidence</span>
            </div>
            <p className="text-2xl font-bold text-purple-600">
              {Math.round(recommendations.reduce((sum, r) => sum + r.confidence, 0) / recommendations.length)}%
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Impact</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Confidence</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recommendations.map((rec) => {
                const item = getItem(rec.itemId);
                if (!item) return null;

                return (
                  <tr 
                    key={rec.id} 
                    className="hover:bg-gray-50 cursor-pointer"
                    onClick={() => setSelectedRec(rec)}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{item.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{rec.type.replace('_', ' ')}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-green-600">${rec.potentialCostImpact.toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{rec.confidence}%</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(rec.status)}`}>
                        {rec.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onAccept(rec);
                          }}
                          className="text-green-600 hover:text-green-900"
                        >
                          <ThumbsUp className="h-5 w-5" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onReject(rec);
                          }}
                          className="text-red-600 hover:text-red-900"
                        >
                          <ThumbsDown className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {selectedRec && (
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Recommendation Details</h3>
            <button
              onClick={() => setSelectedRec(null)}
              className="text-gray-500 hover:text-gray-700"
            >
              ×
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Current Values</h4>
              <dl className="space-y-2">
                <div className="flex justify-between">
                  <dt className="text-gray-500">Current Value</dt>
                  <dd className="font-medium">{selectedRec.currentValue}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">Generated At</dt>
                  <dd className="font-medium">{format(selectedRec.generatedAt, 'PPp')}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">Confidence Level</dt>
                  <dd className="font-medium">{selectedRec.confidence}%</dd>
                </div>
              </dl>
            </div>

            <div>
              <h4 className="font-medium text-gray-700 mb-2">Potential Impact</h4>
              <dl className="space-y-2">
                <div className="flex justify-between">
                  <dt className="text-gray-500">Recommended Value</dt>
                  <dd className="font-medium">{selectedRec.recommendedValue}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">Cost Impact</dt>
                  <dd className="font-medium text-green-600">
                    ${selectedRec.potentialCostImpact.toLocaleString()}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">Service Level Impact</dt>
                  <dd className="font-medium text-blue-600">
                    +{selectedRec.potentialServiceLevelImpact.toFixed(1)}%
                  </dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AIRecommendations;